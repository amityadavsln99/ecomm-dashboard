<?php

namespace App\Http\Controllers\product;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Models\Product;
use App\Models\User;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;

class ProductController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    // protected $redirectTo = '/home';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        // $this->middleware('auth');
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'name' => ['required', 'string', 'max:255'],
            'qty' => ['required'],
            'price' => ['required'],
        ]);
    }

    public function index()
    {
        return view('product.create_product');
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\Models\User
     */
    protected function create(Request $request)
    {
        $data = $request->all();
        $filename = '';
        if(!empty($data['image'])){
            $filename = time().'.'.$data['image']->extension();
            $data['image']->move(public_path('products'), $filename);
        }
        $product_data = [
            'user_id' => Auth::id(),
            'name' => $data['name'],
            'color' => $data['color'],
            'size' => $data['size'],
            'qty' => $data['qty'],
            'price' => $data['price'],
            'image' => $filename,
        ];
        // dd($product_data);
        $product = Product::create($product_data);
        if($product){
            return response()->json(['status'=>true,'data'=>$product,'message'=>"Product Added Successfully",'code'=>1]);
        }else{
            return response()->json(['status'=>false,'data'=>[],'message'=>"Product Not Added Successfully",'code'=>0]);
        }
    }

    public function addProduct(Request $request){
        $product = new Product;
        $product->name = $request->input('name');
        $product->price = $request->input('price');
        $product->description = $request->input('description');
        $product->file_path = $request->file('file')->store('products');
        $product->save();
        return $product;
    }

    public function list(){
        return Product::all();
    }

    public function delete($id){
        $result = Product::where('id',$id)->delete();
        if($result){
            return ["result"=>"product has been deleted"];
        }else{
            return ["result"=>"product has not been deleted"];
        }
    }

    public function getProduct($id){
        return Product::find($id);
    }

    public function updateProduct($id, Request $request) {
        $product = Product::find($id);
        if (!$product) {
            return response()->json(['message' => 'Product not found'], 404);
        }
        $product->name = $request->input('name');
        $product->price = $request->input('price');
        $product->description = $request->input('description');
        if ($request->hasFile('file')) {
            $product->file_path = $request->file('file')->store('products');
        }
        $product->save();
        return response()->json(['message' => 'Product updated successfully'], 200);
    }

    public function search($key){
        return Product::where('name','LIKE',"%$key%")->get();
    }
}
