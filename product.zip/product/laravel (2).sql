-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 15, 2025 at 07:28 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laravel`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2014_10_12_100000_create_password_resets_table', 1),
(4, '2019_08_19_000000_create_failed_jobs_table', 1),
(5, '2019_12_14_000001_create_personal_access_tokens_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `user_id` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(150) DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  `size` varchar(50) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `price` varchar(50) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `user_id`, `name`, `color`, `size`, `qty`, `price`, `image`, `file_path`, `description`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 2, 'jug', 'red', '10', 10, '40', '1716115415.jpg', NULL, NULL, '2024-05-19 10:43:35', '2025-02-13 12:56:49', '2025-02-13 12:56:40'),
(2, 2, 'shoose', 'white', '9', 10, '900', '1716115824.jpg', NULL, NULL, '2024-05-19 10:50:24', '2025-02-13 12:57:02', '2025-02-13 00:00:00'),
(3, 2, 'table', 'red', '2', 10, '150', '1716116165.jpg', NULL, NULL, '2024-05-19 10:56:06', '2025-02-13 12:57:18', '1900-01-13 00:00:00'),
(4, 0, 'Samsung Mobile A 15', NULL, NULL, NULL, '10000', NULL, 'products/Uap9XmMVNBrU8ikoxpMV7ljLOegb463zfnfZ23Kn.webp', 'A samsung mobile', '2025-02-13 07:25:01', '2025-02-13 07:25:01', NULL),
(5, 0, 'samsung galaxy 11', NULL, NULL, NULL, '20000', NULL, 'products/U3wznXdwBCqxziJqG1ldabYWaw9SQBlVD4CFhG3T.jpg', 'A samsung mobile', '2025-02-13 11:47:57', '2025-02-14 08:00:10', NULL),
(6, 0, 'Apple mobile', NULL, NULL, NULL, '150000', NULL, 'products/aH68A6K0bE5PUBh2g9HhvbaKAJcZZEFeLvxKJt38.webp', 'A mobile Apple', '2025-02-13 18:03:49', '2025-02-14 00:02:42', NULL),
(7, 0, 'Deleted Product', NULL, NULL, NULL, '3223432', NULL, 'products/Z9CtuZEM7qQ7MgwTIaBsg1jbfjI1HsN7QY2A0TkI.webp', 'deleted description sd', '2025-02-13 18:19:30', '2025-02-13 18:31:56', '2025-02-13 18:31:56');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(150) DEFAULT NULL,
  `subject` varchar(150) DEFAULT NULL,
  `mark` int(11) DEFAULT NULL,
  `state` varchar(150) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `user_id`, `name`, `subject`, `mark`, `state`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 'amit', 'Hindi', 19, NULL, '2024-09-28 10:09:57', '2025-01-08 15:47:46', '2024-09-28 10:46:15'),
(2, 1, 'vikky1', 'English', 17, NULL, '2024-09-28 10:14:00', '2024-09-28 11:39:20', '2024-09-28 11:39:20'),
(3, 1, 'amit', 'Hindi', 55, NULL, '2024-09-28 11:33:09', '2024-09-28 11:33:09', NULL),
(4, 1, 'abhishek', 'Math', 17, NULL, '2024-09-28 11:38:59', '2024-09-28 11:38:59', NULL),
(5, 1, 'lokesh', 'math1', 17, NULL, '2024-09-28 11:42:26', '2024-09-28 11:43:11', '2024-09-28 11:43:11'),
(8, NULL, 'sunil1', 'Eng', 15, NULL, '2025-01-08 14:53:19', '2025-01-08 15:44:24', NULL),
(9, NULL, 'Mangol', 'Mat', 44, NULL, '2025-01-08 15:48:28', '2025-01-08 15:48:28', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'amit', 'amit@gmail.com', NULL, '$2y$10$neP3e1F.6IJll75Yed8pROuB.r08z53QFvrpObt4PllXTRwZ0Dora', NULL, '2023-09-09 06:57:34', '2023-09-09 06:57:34'),
(2, 'Rajesh kumar', 'rajesh123@gmail.com', NULL, '$2y$12$KW9bwpfKMfRLA/Nm5JTo4eJMGodbJq3UZNjwlk0swfwHLT50zLo8y', NULL, '2024-05-12 00:21:18', '2024-05-12 00:21:18'),
(3, 'vikas', 'vikas@gmail.com', NULL, '$2y$12$Rjir4rbI0XX92IN.QmS49.4wqVue5NkJjmu2cch.2DBHCxHxv5jZC', NULL, '2024-06-09 04:03:40', '2024-06-09 04:03:40'),
(4, 'ravi', 'ravi123@gmail.com', NULL, '$2y$12$/lnRFORp2WAdbSB2wpYf.O5Ynp6Sw8ZLNRFFufZdRb.jGDOhni.ju', NULL, '2024-10-19 01:15:33', '2024-10-19 01:15:33'),
(5, 'anil', 'anil@test.com', NULL, '$2y$12$a0MYvmpdFBU8eV0dUWHDHuz8X6VIJIrdQKZxWQniivLU8VowSQtl2', NULL, '2025-02-04 11:56:36', '2025-02-04 11:56:36'),
(6, 'anand', 'anand@test.com', NULL, '$2y$12$bHSwYtIcF8UMr6MPgix3C.q503SmBtq8i4ajonEw1709qAz1ZTxCS', NULL, '2025-02-04 12:22:10', '2025-02-04 12:22:10'),
(7, 'peter', 'peter@test.com', NULL, '$2y$12$JpANfcOOGGgUrdPi/eYGdu3dUZKxq36TQ0RP5kmyZu6F4vSwc1GwO', NULL, '2025-02-04 12:32:20', '2025-02-04 12:32:20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
